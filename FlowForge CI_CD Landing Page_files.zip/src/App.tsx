import  { lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { motion } from 'framer-motion';

// Lazy-loaded components
const HomePage = lazy(() => import('./pages/HomePage'));
const LoginPage = lazy(() => import('./pages/LoginPage'));
const RegisterPage = lazy(() => import('./pages/RegisterPage'));
const DashboardPage = lazy(() => import('./pages/DashboardPage'));
const ProjectsPage = lazy(() => import('./pages/ProjectsPage'));
const BuildsPage = lazy(() => import('./pages/BuildsPage'));
const BuildDetailsPage = lazy(() => import('./pages/BuildDetailsPage'));
const AnalyticsPage = lazy(() => import('./pages/AnalyticsPage'));

// Loading fallback
const LoadingFallback = () => (
  <div className="flex w-full h-screen items-center justify-center flex-col space-y-3 p-2">
    <div className="w-12 h-12 rounded-full border-4 border-t-blue-500 border-r-transparent border-b-blue-500 border-l-transparent animate-spin" />
    <div className="text-base font-semibold">Loading...</div>
  </div>
);

// App Routes
function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/dashboard" element={<DashboardPage />} />
      <Route path="/dashboard/projects" element={<ProjectsPage />} />
      <Route path="/dashboard/builds" element={<BuildsPage />} />
      <Route path="/dashboard/builds/:id" element={<BuildDetailsPage />} />
      <Route path="/dashboard/analytics" element={<AnalyticsPage />} />
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Suspense fallback={<LoadingFallback />}>
            <AppRoutes />
          </Suspense>
        </motion.div>
      </Router>
    </AuthProvider>
  );
}

export default App;
 