export  interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: string;
}

export interface Build {
  id: string;
  projectId: string;
  projectName: string;
  status: 'queued' | 'running' | 'success' | 'failed' | 'cancelled';
  branch: string;
  commitSha: string;
  commitMessage: string;
  author: string;
  duration: number;
  startedAt: Date;
  finishedAt: Date | null;
  stages: any[];
  artifacts: any[];
}

export interface Project {
  id: string;
  name: string;
  repository: {
    url: string;
    provider: 'github' | 'gitlab' | 'bitbucket';
    fullName: string;
  };
  lastBuild: Build | null;
  successRate: number;
  totalBuilds: number;
  createdAt: Date;
}

export interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  read: boolean;
  timestamp: Date;
  link?: string;
}

export interface StatCard {
  title: string;
  value: string | number;
  change?: {
    value: number;
    trend: 'up' | 'down' | 'neutral';
  };
  icon: React.ReactNode;
  color?: string;
}

export interface FlowForgeImages {
  hero: string;
  features: string;
  howItWorks: string;
  testimonials: string;
  cta: string;
}
 