import  { Build, Project, Notification, StatCard } from '../types';
import { format, subDays, subMinutes, subHours } from 'date-fns';
import { Activity, Package, Clock, CheckCircle } from 'lucide-react';

// Generate mock projects
export const generateProjects = (): Project[] => {
  const repositories = [
    { name: 'web-frontend', provider: 'github', org: 'flowforge' },
    { name: 'api-backend', provider: 'github', org: 'flowforge' },
    { name: 'mobile-app', provider: 'github', org: 'flowforge' },
    { name: 'infrastructure', provider: 'gitlab', org: 'flowforge-ops' },
    { name: 'documentation', provider: 'github', org: 'flowforge' },
    { name: 'analytics-service', provider: 'github', org: 'flowforge' },
    { name: 'auth-service', provider: 'gitlab', org: 'flowforge-ops' },
    { name: 'monitoring', provider: 'github', org: 'flowforge' },
  ];

  return repositories.map((repo, index) => ({
    id: `proj-${index + 1}`,
    name: repo.name,
    repository: {
      url: `https://${repo.provider}.com/${repo.org}/${repo.name}`,
      provider: repo.provider as 'github' | 'gitlab' | 'bitbucket',
      fullName: `${repo.org}/${repo.name}`,
    },
    lastBuild: null, // Will be populated with generateBuilds
    successRate: 70 + Math.floor(Math.random() * 30),
    totalBuilds: 50 + Math.floor(Math.random() * 200),
    createdAt: subDays(new Date(), 30 + Math.floor(Math.random() * 90)),
  }));
};

// Generate mock builds
export const generateBuilds = (projects: Project[]): Build[] => {
  const statuses: ('queued' | 'running' | 'success' | 'failed' | 'cancelled')[] = ['queued', 'running', 'success', 'failed', 'cancelled'];
  const branches = ['main', 'develop', 'feature/auth', 'feature/ui-updates', 'bugfix/api-issue', 'release/v1.2.0'];
  const commitMessages = [
    'Update README.md',
    'Fix authentication bug',
    'Add new dashboard feature',
    'Improve test coverage',
    'Refactor API endpoints',
    'Optimize build performance',
    'Update dependencies',
    'Fix failing tests',
    'Merge pull request #123 from user/branch',
  ];
  const authors = [
    'Sarah Chen',
    'Michael Rodriguez',
    'Jennifer Park',
    'David Wong',
    'Emily Takahashi',
    'James Smith',
  ];

  const builds: Build[] = [];

  // Create builds for each project
  projects.forEach(project => {
    const numBuilds = 5 + Math.floor(Math.random() * 10);
    
    for (let i = 0; i < numBuilds; i++) {
      const status = statuses[Math.floor(Math.random() * statuses.length)];
      const startedAt = subDays(new Date(), Math.floor(Math.random() * 14));
      const duration = status === 'queued' ? 0 : (1 + Math.floor(Math.random() * 15)) * 60 * 1000; // 1-15 minutes in ms
      const finishedAt = status === 'queued' || status === 'running' ? null : new Date(startedAt.getTime() + duration);
      
      const build: Build = {
        id: `build-${project.id}-${i}`,
        projectId: project.id,
        projectName: project.name,
        status,
        branch: branches[Math.floor(Math.random() * branches.length)],
        commitSha: Math.random().toString(36).substring(2, 10),
        commitMessage: commitMessages[Math.floor(Math.random() * commitMessages.length)],
        author: authors[Math.floor(Math.random() * authors.length)],
        duration,
        startedAt,
        finishedAt,
        stages: generateBuildStages(status),
        artifacts: status === 'success' ? generateArtifacts() : [],
      };
      
      builds.push(build);
      
      // Set the most recent build as the project's lastBuild
      if (i === 0) {
        project.lastBuild = build;
      }
    }
  });
  
  // Sort builds by startedAt (newest first)
  return builds.sort((a, b) => b.startedAt.getTime() - a.startedAt.getTime());
};

// Generate mock build stages
const generateBuildStages = (buildStatus: string): any[] => {
  const stageNames = ['checkout', 'install', 'lint', 'test', 'build', 'deploy'];
  let currentStatus: 'pending' | 'running' | 'success' | 'failed' | 'cancelled' = 'success';
  
  return stageNames.map((name, index) => {
    if (buildStatus === 'queued') {
      currentStatus = 'pending';
    } else if (buildStatus === 'running') {
      currentStatus = index < 3 ? 'success' : index === 3 ? 'running' : 'pending';
    } else if (buildStatus === 'failed') {
      currentStatus = index < 4 ? 'success' : index === 4 ? 'failed' : 'cancelled';
    } else if (buildStatus === 'cancelled') {
      currentStatus = index < 3 ? 'success' : 'cancelled';
    }
    
    const startedAt = currentStatus === 'pending' ? null : subMinutes(new Date(), 30 - index * 5);
    const finishedAt = (currentStatus === 'pending' || currentStatus === 'running') ? null : startedAt ? new Date(startedAt.getTime() + (index + 1) * 60 * 1000) : null;
    const duration = startedAt && finishedAt ? finishedAt.getTime() - startedAt.getTime() : null;
    
    return {
      id: `stage-${index}`,
      name,
      status: currentStatus,
      startedAt,
      finishedAt,
      duration,
      logs: currentStatus !== 'pending' ? generateLogs(name, currentStatus) : [],
    };
  });
};

// Generate mock artifacts
const generateArtifacts = (): any[] => {
  const artifactTypes = [
    { name: 'app.zip', type: 'application/zip', size: 15.7 * 1024 * 1024 },
    { name: 'coverage.html', type: 'text/html', size: 256 * 1024 },
    { name: 'test-results.xml', type: 'application/xml', size: 128 * 1024 },
    { name: 'bundle-analysis.json', type: 'application/json', size: 64 * 1024 },
    { name: 'logs.txt', type: 'text/plain', size: 512 * 1024 },
  ];
  
  return artifactTypes.map((artifact, index) => ({
    id: `artifact-${index}`,
    name: artifact.name,
    size: artifact.size,
    type: artifact.type,
    url: `#/artifacts/${artifact.name}`,
  }));
};

// Generate mock logs
const generateLogs = (stageName: string, status: string): string[] => {
  const commonLogs = [
    `[INFO] Starting stage: ${stageName}`,
    `[INFO] Using Node.js 18.15.0`,
    `[INFO] Using npm 9.5.0`,
  ];
  
  const stageSpecificLogs: Record<string, string[]> = {
    checkout: [
      '[INFO] git init',
      '[INFO] git remote add origin https://github.com/flowforge/repo.git',
      '[INFO] git fetch --progress --depth=1 origin +refs/heads/main:refs/remotes/origin/main',
      '[INFO] git checkout --progress --force -B main refs/remotes/origin/main',
      '[INFO] Checking out 7f8e921a as main',
    ],
    install: [
      '[INFO] npm ci',
      '[INFO] added 1284 packages in 24s',
      '[INFO] 127 packages are looking for funding',
    ],
    lint: [
      '[INFO] npm run lint',
      '[INFO] > lint',
      '[INFO] > eslint . --ext .js,.jsx,.ts,.tsx',
      '[INFO] Linting complete: 0 errors, 2 warnings found in 156 files',
    ],
    test: [
      '[INFO] npm run test',
      '[INFO] > test',
      '[INFO] > jest --coverage',
      '[INFO] PASS src/components/__tests__/Button.test.tsx',
      '[INFO] PASS src/utils/__tests__/format.test.ts',
      '[INFO] Test Suites: 24 passed, 24 total',
      '[INFO] Tests: 142 passed, 142 total',
      '[INFO] Coverage: 89.2%',
    ],
    build: [
      '[INFO] npm run build',
      '[INFO] > build',
      '[INFO] > next build',
      '[INFO] info  - Loaded env from .env',
      '[INFO] info  - Linting and checking validity of types',
      '[INFO] info  - Creating an optimized production build',
      '[INFO] info  - Compiled successfully',
      '[INFO] info  - Collecting page data',
      '[INFO] info  - Generating static pages (8/8)',
      '[INFO] info  - Finalizing page optimization',
      status === 'failed' ? '[ERROR] Failed to compile: Module not found: Error: Can\'t resolve \'missing-module\'' : '[INFO] Build completed successfully',
    ],
    deploy: [
      '[INFO] Deploying to production',
      '[INFO] Uploading build artifacts',
      '[INFO] Configuring CDN',
      '[INFO] Updating database schema',
      '[INFO] Restarting application servers',
      '[INFO] Running smoke tests',
      '[INFO] Deployment complete',
    ],
  };
  
  let logs = [...commonLogs, ...stageSpecificLogs[stageName]];
  
  if (status === 'failed') {
    logs.push('[ERROR] Stage failed with exit code 1');
  } else if (status === 'cancelled') {
    logs.push('[WARN] Stage was cancelled');
  } else if (status === 'success') {
    logs.push(`[INFO] Stage completed successfully in ${Math.floor(Math.random() * 60)} seconds`);
  }
  
  return logs;
};

// Generate mock notifications
export const generateNotifications = (): Notification[] => {
  const notificationTypes = [
    { type: 'success', title: 'Build successful', message: 'Project "web-frontend" build #1234 completed successfully.' },
    { type: 'error', title: 'Build failed', message: 'Project "api-backend" build #567 failed during test stage.' },
    { type: 'warning', title: 'Long build time', message: 'Project "mobile-app" build #890 took 15 minutes, which is 50% longer than average.' },
    { type: 'info', title: 'New feature available', message: 'FlowForge now supports caching dependencies between builds.' },
    { type: 'success', title: 'Deployment successful', message: 'Project "infrastructure" was successfully deployed to production.' },
    { type: 'error', title: 'API rate limit exceeded', message: 'GitHub API rate limit reached. Some operations may be delayed.' },
  ];
  
  return notificationTypes.map((notification, index) => ({
    id: `notif-${index}`,
    type: notification.type as 'success' | 'error' | 'warning' | 'info',
    title: notification.title,
    message: notification.message,
    read: Math.random() > 0.6,
    timestamp: subHours(new Date(), index * 2 + Math.floor(Math.random() * 5)),
    link: index % 3 === 0 ? '#/builds/build-123' : undefined,
  }));
};

// Generate dashboard stats
export const generateDashboardStats = (): StatCard[] => {
  return [
    {
      title: 'Total Builds',
      value: 1248,
      change: { value: 12, trend: 'up' },
      icon: <Activity size={20} />,
      color: 'text-blue-500',
    },
    {
      title: 'Success Rate',
      value: '92%',
      change: { value: 3, trend: 'up' },
      icon: <CheckCircle size={20} />,
      color: 'text-emerald-500',
    },
    {
      title: 'Build Minutes',
      value: '7,532',
      change: { value: 8, trend: 'up' },
      icon: <Clock size={20} />,
      color: 'text-purple-500',
    },
    {
      title: 'Active Projects',
      value: 8,
      change: { value: 1, trend: 'up' },
      icon: <Package size={20} />,
      color: 'text-amber-500',
    }
  ];
};

// Generate usage data for charts
export const generateUsageData = () => {
  const days = Array.from({ length: 30 }, (_, i) => {
    const date = subDays(new Date(), 29 - i);
    return format(date, 'MMM dd');
  });

  return {
    buildActivity: days.map(day => ({
      date: day,
      total: 5 + Math.floor(Math.random() * 20),
      success: 4 + Math.floor(Math.random() * 15),
      failed: 1 + Math.floor(Math.random() * 5),
    })),
    
    buildDuration: days.map(day => ({
      date: day,
      duration: 2 + Math.random() * 8,
    })),
    
    resourceUsage: days.map(day => ({
      date: day,
      cpu: 20 + Math.random() * 60,
      memory: 30 + Math.random() * 50,
    })),
  };
};

// Generate team members
export const generateTeamMembers = () => {
  return [
    {
      id: 'user-1',
      name: 'Sarah Chen',
      email: 'sarah@example.com',
      role: 'Admin',
      avatar: 'https://randomuser.me/api/portraits/women/44.jpg',
      lastActive: 'Just now',
    },
    {
      id: 'user-2',
      name: 'Michael Rodriguez',
      email: 'michael@example.com',
      role: 'Developer',
      avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
      lastActive: '5 minutes ago',
    },
    {
      id: 'user-3',
      name: 'Jennifer Park',
      email: 'jennifer@example.com',
      role: 'DevOps',
      avatar: 'https://randomuser.me/api/portraits/women/68.jpg',
      lastActive: '1 hour ago',
    },
    {
      id: 'user-4',
      name: 'David Wong',
      email: 'david@example.com',
      role: 'Developer',
      avatar: 'https://randomuser.me/api/portraits/men/75.jpg',
      lastActive: '2 hours ago',
    },
  ];
};
 