//  This file would typically contain API calls to your backend service
// For this demo, we'll use local storage for persistence

const BASE_URL = 'https://hooks.jdoodle.net/proxy?url=https://api.example.com';

// Function to make authenticated requests to our backend (via proxy)
export async function apiRequest(endpoint: string, options = {}) {
  const token = localStorage.getItem('flowforge_token');
  
  const defaultOptions = {
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    }
  };
  
  const mergedOptions = {
    ...defaultOptions,
    ...options,
    headers: {
      ...defaultOptions.headers,
      ...(options as any).headers
    }
  };
  
  try {
    const response = await fetch(`${BASE_URL}${endpoint}`, mergedOptions);
    
    if (!response.ok) {
      const error = await response.json().catch(() => null);
      throw new Error(error?.message || `API error: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
}

// Mock function to simulate GitHub OAuth flow
export async function initiateGithubOAuth() {
  // In a real app, this would redirect to GitHub's OAuth flow
  // For demo purposes, we'll just simulate success
  return { success: true };
}

// Get user data (demo function)
export async function getUserData() {
  try {
    // In a real app, this would make an API call
    const storedUser = localStorage.getItem('flowforge_user');
    if (!storedUser) return null;
    return JSON.parse(storedUser);
  } catch (error) {
    console.error('Error getting user data:', error);
    return null;
  }
}
 