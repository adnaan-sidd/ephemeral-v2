import  { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { getUserData } from '../utils/api';

interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

interface AuthContextType {
  isAuthenticated: boolean;
  user: User | null;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  loginWithGithub: () => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Check if user is already logged in
  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const userData = await getUserData();
        setUser(userData);
      } catch (error) {
        console.error('Failed to get user data:', error);
      } finally {
        setLoading(false);
      }
    };

    checkAuthStatus();
  }, []);

  // Mock login function
  const login = async (email: string, password: string) => {
    setLoading(true);
    setError(null);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // For demo purposes, always succeed except for specific test cases
      if (email === 'error@example.com') {
        throw new Error('Invalid credentials');
      }
      
      const mockUser = {
        id: '1',
        name: email.split('@')[0],
        email,
        avatar: `https://randomuser.me/api/portraits/${Math.random() > 0.5 ? 'men' : 'women'}/${Math.floor(Math.random() * 100)}.jpg`,
      };
      
      setUser(mockUser);
      localStorage.setItem('flowforge_user', JSON.stringify(mockUser));
      localStorage.setItem('flowforge_token', 'mock-jwt-token');
    } catch (error) {
      setError((error as Error).message || 'Failed to login');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Mock GitHub login
  const loginWithGithub = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockUser = {
        id: '2',
        name: 'GitHub User',
        email: 'github_user@example.com',
        avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
      };
      
      setUser(mockUser);
      localStorage.setItem('flowforge_user', JSON.stringify(mockUser));
      localStorage.setItem('flowforge_token', 'mock-github-jwt-token');
    } catch (error) {
      setError((error as Error).message || 'Failed to login with GitHub');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Mock register function
  const register = async (name: string, email: string, password: string) => {
    setLoading(true);
    setError(null);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // For demo purposes, always succeed except for specific test cases
      if (email === 'existing@example.com') {
        throw new Error('Email already exists');
      }
      
      const mockUser = {
        id: '3',
        name,
        email,
        avatar: `https://randomuser.me/api/portraits/${Math.random() > 0.5 ? 'men' : 'women'}/${Math.floor(Math.random() * 100)}.jpg`,
      };
      
      setUser(mockUser);
      localStorage.setItem('flowforge_user', JSON.stringify(mockUser));
      localStorage.setItem('flowforge_token', 'mock-jwt-token');
    } catch (error) {
      setError((error as Error).message || 'Failed to register');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Logout function
  const logout = () => {
    setUser(null);
    localStorage.removeItem('flowforge_user');
    localStorage.removeItem('flowforge_token');
  };

  const value = {
    isAuthenticated: !!user,
    user,
    loading,
    error,
    login,
    loginWithGithub,
    register,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
 