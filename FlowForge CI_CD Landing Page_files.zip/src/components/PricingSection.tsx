import  { useState } from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

const pricingTiers = [
  {
    name: "Starter",
    price: 20,
    description: "Perfect for side projects and small teams",
    features: [
      "1,000 build minutes",
      "3 concurrent builds",
      "10 projects",
      "7-day build history",
      "Community support",
      "Standard environments"
    ],
    highlighted: false,
    cta: "Start Free Trial"
  },
  {
    name: "Professional",
    price: 50,
    description: "For growing teams with more demanding needs",
    features: [
      "3,000 build minutes",
      "5 concurrent builds",
      "Unlimited projects",
      "30-day build history",
      "Priority support",
      "Custom environments",
      "Build caching",
      "Advanced analytics"
    ],
    highlighted: true,
    cta: "Start Free Trial"
  },
  {
    name: "Team",
    price: 200,
    description: "For larger teams with complex workflows",
    features: [
      "10,000 build minutes",
      "10 concurrent builds",
      "Unlimited projects",
      "90-day build history",
      "Priority support",
      "Custom environments",
      "Build caching",
      "Advanced analytics",
      "SAML SSO",
      "Dedicated support"
    ],
    highlighted: false,
    cta: "Start Free Trial"
  },
  {
    name: "Enterprise",
    price: null,
    description: "For organizations with custom requirements",
    features: [
      "Unlimited build minutes",
      "Unlimited concurrent builds",
      "Unlimited projects",
      "1-year build history",
      "24/7 support",
      "Custom environments",
      "Build caching",
      "Advanced analytics",
      "SAML SSO",
      "Dedicated support",
      "Custom integrations",
      "On-premises option",
      "SLA guarantee"
    ],
    highlighted: false,
    cta: "Contact Sales"
  }
];

export default function PricingSection() {
  const [annual, setAnnual] = useState(false);
  
  // Calculate the discount amount
  const discountPercentage = 20;
  const getDiscountedPrice = (price: number) => {
    return Math.round(price * (1 - discountPercentage / 100) * 12) / 12;
  };

  return (
    <section id="pricing" className="py-20 bg-gray-50 dark:bg-gray-800">
      <div className="container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-3xl mx-auto mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-violet-600">
            Simple, Transparent Pricing
          </h2>
          <p className="text-lg text-gray-700 dark:text-gray-300 mb-8">
            Choose the plan that's right for your team. All plans include a 14-day free trial.
          </p>
          
          {/* Billing toggle */}
          <div className="flex items-center justify-center mb-8">
            <span className={`text-sm ${!annual ? 'text-gray-900 dark:text-white font-medium' : 'text-gray-500 dark:text-gray-400'}`}>
              Monthly
            </span>
            <button 
              onClick={() => setAnnual(!annual)}
              className="relative mx-4 w-14 h-7 bg-gray-200 dark:bg-gray-700 rounded-full p-1 transition duration-300 ease-in-out"
            >
              <div 
                className={`absolute left-1 top-1 bg-white dark:bg-gray-900 w-5 h-5 rounded-full shadow transform transition-transform duration-300 ease-in-out ${
                  annual ? 'translate-x-7' : 'translate-x-0'
                }`}
              />
            </button>
            <span className={`text-sm ${annual ? 'text-gray-900 dark:text-white font-medium' : 'text-gray-500 dark:text-gray-400'}`}>
              Annual <span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 text-xs px-2 py-0.5 rounded-full ml-1">Save 20%</span>
            </span>
          </div>
        </motion.div>

        {/* Pricing cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {pricingTiers.map((tier, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`relative bg-white dark:bg-gray-900 rounded-xl shadow-lg border overflow-hidden ${
                tier.highlighted 
                  ? 'border-blue-500 dark:border-blue-400' 
                  : 'border-gray-200 dark:border-gray-700'
              }`}
            >
              {tier.highlighted && (
                <div className="absolute top-0 left-0 right-0 bg-blue-500 text-white py-1 text-sm text-center font-medium">
                  Most Popular
                </div>
              )}
              
              <div className={`p-6 ${tier.highlighted ? 'pt-10' : 'pt-6'}`}>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                  {tier.name}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">
                  {tier.description}
                </p>
                
                <div className="mb-6">
                  {tier.price ? (
                    <>
                      <span className="text-4xl font-bold text-gray-900 dark:text-white">
                        ${annual ? getDiscountedPrice(tier.price) : tier.price}
                      </span>
                      <span className="text-gray-600 dark:text-gray-400 ml-1">
                        /mo
                      </span>
                      {annual && (
                        <div className="text-sm text-green-600 dark:text-green-400 mt-1">
                          ${tier.price * 12 - (getDiscountedPrice(tier.price) * 12)} saved annually
                        </div>
                      )}
                    </>
                  ) : (
                    <span className="text-4xl font-bold text-gray-900 dark:text-white">
                      Custom
                    </span>
                  )}
                </div>
                
                <button 
                  className={`w-full py-2 px-4 rounded-lg font-medium transition-all ${
                    tier.highlighted 
                      ? 'bg-gradient-to-r from-blue-600 to-violet-600 text-white hover:shadow-lg' 
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-700'
                  }`}
                >
                  {tier.cta}
                </button>
              </div>
              
              <div className="border-t border-gray-200 dark:border-gray-700 p-6">
                <ul className="space-y-3">
                  {tier.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                      <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                      <span className="text-gray-700 dark:text-gray-300 text-sm">
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>
        
        {/* Enterprise CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mt-16 text-center"
        >
          <p className="text-gray-700 dark:text-gray-300 mb-4">
            Need a custom solution? Contact our sales team for a tailored quote.
          </p>
          <button className="px-6 py-3 bg-white dark:bg-gray-800 text-gray-900 dark:text-white border border-gray-300 dark:border-gray-700 rounded-lg hover:shadow-md transition-all">
            Contact Sales
          </button>
        </motion.div>
      </div>
    </section>
  );
}
 