import  { Zap } from 'lucide-react';
import { motion } from 'framer-motion';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  animated?: boolean;
  className?: string;
}

export default function Logo({ size = 'md', animated = true, className = '' }: LogoProps) {
  const sizeClasses = {
    sm: 'text-xl',
    md: 'text-2xl',
    lg: 'text-3xl'
  };

  const iconSizes = {
    sm: 16,
    md: 24,
    lg: 32
  };

  const textSizes = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-lg'
  };

  return (
    <div className={`flex items-center ${className}`}>
      <div className="relative">
        {animated ? (
          <motion.div
            className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-blue-500 to-violet-500 rounded-full opacity-80"
            animate={{
              scale: [1, 1.1, 1],
              opacity: [0.7, 0.9, 0.7]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              repeatType: "reverse"
            }}
          />
        ) : null}
        <div className="relative flex items-center justify-center bg-gradient-to-r from-blue-600 to-violet-600 rounded-full p-2">
          <Zap size={iconSizes[size]} className="text-white" />
        </div>
      </div>
      <div className={`ml-2 font-bold ${sizeClasses[size]} bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-violet-600`}>
        FlowForge
      </div>
      <div className={`ml-1 ${textSizes[size]} text-gray-500 dark:text-gray-400`}>CI/CD</div>
    </div>
  );
}
 