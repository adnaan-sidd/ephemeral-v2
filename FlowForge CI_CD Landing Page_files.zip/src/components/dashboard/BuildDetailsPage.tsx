import  { useState } from 'react';
import { motion } from 'framer-motion';
import { useParams } from 'react-router-dom';
import { format } from 'date-fns';
import { 
  GitBranch, 
  User, 
  Clock, 
  CalendarClock,
  Package,
  RefreshCw,
  Share,
  Download,
  Terminal,
  FileText,
  Check,
  X,
  Play
} from 'lucide-react';
import { Build, BuildStage } from '../../types';
import BuildStatusBadge from './BuildStatusBadge';

interface BuildDetailsPageProps {
  build: Build;
}

function StageIndicator({ stage, index, totalStages }: { stage: BuildStage; index: number; totalStages: number }) {
  const stageStatusColors = {
    pending: 'bg-gray-300 dark:bg-gray-600',
    running: 'bg-blue-500 dark:bg-blue-400',
    success: 'bg-green-500 dark:bg-green-400',
    failed: 'bg-red-500 dark:bg-red-400',
    cancelled: 'bg-amber-500 dark:bg-amber-400',
  };
  
  return (
    <div className="flex flex-col items-center">
      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
        stage.status === 'success' 
          ? 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400' 
          : stage.status === 'failed' 
            ? 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400' 
            : stage.status === 'running' 
              ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400' 
              : 'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400'
      }`}>
        {stage.status === 'success' ? (
          <Check size={16} />
        ) : stage.status === 'failed' ? (
          <X size={16} />
        ) : stage.status === 'running' ? (
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          >
            <RefreshCw size={16} />
          </motion.div>
        ) : (
          <Play size={16} />
        )}
      </div>
      <div className="mt-2 text-xs font-medium">{stage.name}</div>
      {index < totalStages - 1 && (
        <div className={`w-1 h-6 mt-1 ${stageStatusColors[stage.status]}`}></div>
      )}
    </div>
  );
}

export default function BuildDetailsPage({ build }: BuildDetailsPageProps) {
  const [activeTab, setActiveTab] = useState('logs'); // 'logs', 'artifacts', 'config'
  const [activeStage, setActiveStage] = useState(build.stages[0]?.id || '');
  
  // Format duration in minutes and seconds
  const formatDuration = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    return minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`;
  };
  
  // Get the active stage logs
  const activeStageLogs = build.stages.find(stage => stage.id === activeStage)?.logs || [];
  
  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex flex-col md:flex-row md:items-start justify-between mb-6">
          <div>
            <div className="flex items-center mb-1">
              <Package className="mr-2 text-gray-500" size={20} />
              <h1 className="text-2xl font-bold">{build.projectName}</h1>
              <span className="ml-2 text-gray-500 dark:text-gray-400">#{build.id.split('-').pop()}</span>
            </div>
            <p className="text-gray-600 dark:text-gray-400">{build.commitMessage}</p>
          </div>
          
          <div className="mt-4 md:mt-0 flex items-center space-x-3">
            <button className="inline-flex items-center px-3 py-1.5 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700">
              <Share size={16} className="mr-1.5" />
              Share
            </button>
            
            <button className="inline-flex items-center px-3 py-1.5 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700">
              <Download size={16} className="mr-1.5" />
              Download
            </button>
            
            <button className="inline-flex items-center px-3 py-1.5 border border-primary-500 rounded-md text-sm font-medium text-white bg-primary-500 hover:bg-primary-600">
              <RefreshCw size={16} className="mr-1.5" />
              Rebuild
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="glass-card p-6 col-span-3 md:col-span-2">
            <div className="flex items-center space-x-4 mb-6">
              <BuildStatusBadge status={build.status} size="lg" />
              
              <div className="h-5 w-px bg-gray-300 dark:bg-gray-700"></div>
              
              <div className="flex items-center text-gray-600 dark:text-gray-400">
                <GitBranch size={16} className="mr-1.5" />
                <span>{build.branch}</span>
                <span className="ml-2 text-xs bg-gray-100 dark:bg-gray-700 px-1.5 py-0.5 rounded font-mono">
                  {build.commitSha.substring(0, 7)}
                </span>
              </div>
              
              <div className="h-5 w-px bg-gray-300 dark:bg-gray-700"></div>
              
              <div className="flex items-center text-gray-600 dark:text-gray-400">
                <User size={16} className="mr-1.5" />
                <span>{build.author}</span>
              </div>
            </div>
            
            <div className="flex flex-wrap items-center justify-between mb-6 border-t border-b border-gray-200 dark:border-gray-700 py-4">
              <div className="flex items-center mr-6 mb-2 md:mb-0">
                <CalendarClock size={16} className="mr-1.5 text-gray-500" />
                <div>
                  <div className="text-sm font-medium">Started</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    {format(new Date(build.startedAt), 'MMM d, yyyy HH:mm:ss')}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center mr-6 mb-2 md:mb-0">
                <Clock size={16} className="mr-1.5 text-gray-500" />
                <div>
                  <div className="text-sm font-medium">Duration</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    {formatDuration(build.duration)}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center">
                <CalendarClock size={16} className="mr-1.5 text-gray-500" />
                <div>
                  <div className="text-sm font-medium">Finished</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    {build.finishedAt 
                      ? format(new Date(build.finishedAt), 'MMM d, yyyy HH:mm:ss')
                      : 'In progress...'}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-4">Pipeline Stages</h3>
              
              <div className="flex flex-col items-stretch">
                <div className="flex justify-around mb-6">
                  {build.stages.map((stage, index) => (
                    <StageIndicator 
                      key={stage.id} 
                      stage={stage} 
                      index={index} 
                      totalStages={build.stages.length} 
                    />
                  ))}
                </div>
                
                <div className="flex border-b border-gray-200 dark:border-gray-700">
                  <button
                    className={`px-4 py-2 font-medium text-sm ${
                      activeTab === 'logs' 
                        ? 'text-primary-600 dark:text-primary-400 border-b-2 border-primary-500' 
                        : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
                    }`}
                    onClick={() => setActiveTab('logs')}
                  >
                    <Terminal size={16} className="inline mr-1.5" />
                    Logs
                  </button>
                  
                  <button
                    className={`px-4 py-2 font-medium text-sm ${
                      activeTab === 'artifacts' 
                        ? 'text-primary-600 dark:text-primary-400 border-b-2 border-primary-500' 
                        : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
                    }`}
                    onClick={() => setActiveTab('artifacts')}
                  >
                    <FileText size={16} className="inline mr-1.5" />
                    Artifacts
                  </button>
                  
                  <button
                    className={`px-4 py-2 font-medium text-sm ${
                      activeTab === 'config' 
                        ? 'text-primary-600 dark:text-primary-400 border-b-2 border-primary-500' 
                        : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
                    }`}
                    onClick={() => setActiveTab('config')}
                  >
                    <FileText size={16} className="inline mr-1.5" />
                    Configuration
                  </button>
                </div>
                
                <div className="mt-4">
                  {activeTab === 'logs' && (
                    <div>
                      <div className="flex mb-3 border-b border-gray-200 dark:border-gray-700 overflow-x-auto">
                        {build.stages.map((stage) => (
                          <button
                            key={stage.id}
                            className={`px-3 py-2 text-sm font-medium whitespace-nowrap ${
                              activeStage === stage.id 
                                ? 'text-primary-600 dark:text-primary-400 border-b-2 border-primary-500' 
                                : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
                            }`}
                            onClick={() => setActiveStage(stage.id)}
                          >
                            {stage.name}
                          </button>
                        ))}
                      </div>
                      
                      <div className="bg-gray-900 rounded-md p-4 text-gray-300 font-mono text-sm overflow-auto h-96">
                        {activeStageLogs.length > 0 ? (
                          activeStageLogs.map((log, index) => (
                            <div key={index} className="whitespace-pre-wrap">
                              <span className="text-gray-500">[{index + 1}] </span>
                              <span className={`${
                                log.includes('[ERROR]') 
                                  ? 'text-red-400' 
                                  : log.includes('[WARN]') 
                                    ? 'text-yellow-400' 
                                    : log.includes('[INFO]') 
                                      ? 'text-blue-400' 
                                      : ''
                              }`}>
                                {log}
                              </span>
                            </div>
                          ))
                        ) : (
                          <div className="text-gray-500">No logs available for this stage.</div>
                        )}
                      </div>
                    </div>
                  )}
                  
                  {activeTab === 'artifacts' && (
                    <div>
                      {build.artifacts.length > 0 ? (
                        <ul className="divide-y divide-gray-200 dark:divide-gray-700">
                          {build.artifacts.map((artifact) => (
                            <li key={artifact.id} className="py-3">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center">
                                  <FileText size={18} className="text-gray-500 mr-3" />
                                  <div>
                                    <p className="font-medium">{artifact.name}</p>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">
                                      {(artifact.size / 1024).toFixed(1)} KB • {artifact.type}
                                    </p>
                                  </div>
                                </div>
                                <button className="text-primary-600 dark:text-primary-400 hover:text-primary-800 dark:hover:text-primary-300">
                                  <Download size={18} />
                                </button>
                              </div>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <div className="text-center py-12">
                          <FileText size={48} className="mx-auto text-gray-300 dark:text-gray-700 mb-4" />
                          <p className="text-gray-500 dark:text-gray-400 text-lg mb-2">No artifacts available</p>
                          <p className="text-gray-400 dark:text-gray-500 text-sm max-w-md mx-auto">
                            This build hasn't produced any artifacts or hasn't completed successfully.
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {activeTab === 'config' && (
                    <div className="bg-gray-900 rounded-md p-4 text-gray-300 font-mono text-sm overflow-auto h-96">
                      <pre>{`version: 1.0

pipeline:
  name: ${build.projectName}
  
stages:
  - name: checkout
    commands:
      - git checkout ${build.branch}
      - git pull origin ${build.branch}
      
  - name: install
    commands:
      - npm ci
      
  - name: lint
    commands:
      - npm run lint
      
  - name: test
    commands:
      - npm run test
      
  - name: build
    commands:
      - npm run build
      
  - name: deploy
    commands:
      - npx firebase deploy --only hosting
      
environment:
  NODE_VERSION: 18
  NPM_CONFIG_PRODUCTION: false
  
cache:
  paths:
    - node_modules/
    - .next/cache/
    
notifications:
  slack: '#deployments'
  email: ${build.author}
`}</pre>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          <div className="glass-card p-6 col-span-3 md:col-span-1">
            <h3 className="text-lg font-semibold mb-4">Build Information</h3>
            
            <ul className="space-y-4">
              <li className="flex items-start">
                <div className="w-24 flex-shrink-0 text-sm text-gray-500 dark:text-gray-400">Project</div>
                <div className="font-medium">{build.projectName}</div>
              </li>
              <li className="flex items-start">
                <div className="w-24 flex-shrink-0 text-sm text-gray-500 dark:text-gray-400">Build ID</div>
                <div className="font-medium">{build.id}</div>
              </li>
              <li className="flex items-start">
                <div className="w-24 flex-shrink-0 text-sm text-gray-500 dark:text-gray-400">Commit</div>
                <div className="font-medium">{build.commitSha}</div>
              </li>
              <li className="flex items-start">
                <div className="w-24 flex-shrink-0 text-sm text-gray-500 dark:text-gray-400">Message</div>
                <div className="font-medium">{build.commitMessage}</div>
              </li>
              <li className="flex items-start">
                <div className="w-24 flex-shrink-0 text-sm text-gray-500 dark:text-gray-400">Branch</div>
                <div className="font-medium">{build.branch}</div>
              </li>
              <li className="flex items-start">
                <div className="w-24 flex-shrink-0 text-sm text-gray-500 dark:text-gray-400">Author</div>
                <div className="font-medium">{build.author}</div>
              </li>
              <li className="flex items-start">
                <div className="w-24 flex-shrink-0 text-sm text-gray-500 dark:text-gray-400">Started</div>
                <div className="font-medium">{format(new Date(build.startedAt), 'MMM d, yyyy HH:mm:ss')}</div>
              </li>
              {build.finishedAt && (
                <li className="flex items-start">
                  <div className="w-24 flex-shrink-0 text-sm text-gray-500 dark:text-gray-400">Finished</div>
                  <div className="font-medium">{format(new Date(build.finishedAt), 'MMM d, yyyy HH:mm:ss')}</div>
                </li>
              )}
              <li className="flex items-start">
                <div className="w-24 flex-shrink-0 text-sm text-gray-500 dark:text-gray-400">Duration</div>
                <div className="font-medium">{formatDuration(build.duration)}</div>
              </li>
              <li className="flex items-start">
                <div className="w-24 flex-shrink-0 text-sm text-gray-500 dark:text-gray-400">Status</div>
                <div>
                  <BuildStatusBadge status={build.status} />
                </div>
              </li>
            </ul>
            
            <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
              <h4 className="font-medium mb-3">Related Builds</h4>
              
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-md bg-gray-50 dark:bg-gray-850 hover:bg-gray-100 dark:hover:bg-gray-800">
                    <div className="flex items-center">
                      <div className={`w-2 h-2 rounded-full ${i === 1 ? 'bg-green-500' : i === 2 ? 'bg-red-500' : 'bg-gray-500'} mr-2`}></div>
                      <div>
                        <div className="text-sm font-medium">Build #{(5432 - i).toString()}</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">{['2 hours ago', '4 hours ago', '6 hours ago'][i - 1]}</div>
                      </div>
                    </div>
                    <BuildStatusBadge status={i === 1 ? 'success' : i === 2 ? 'failed' : 'cancelled'} size="sm" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
 