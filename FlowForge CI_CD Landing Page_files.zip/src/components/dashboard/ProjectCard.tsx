import  { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { Github, Gitlab, Package, Play, Settings } from 'lucide-react';
import { Project } from '../../types';
import BuildStatusBadge from './BuildStatusBadge';

interface ProjectCardProps {
  project: Project;
}

export default function ProjectCard({ project }: ProjectCardProps) {
  const ProviderIcon = project.repository.provider === 'github' ? Github : project.repository.provider === 'gitlab' ? Gitlab : Package;
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden"
    >
      <div className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="w-10 h-10 rounded-lg bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 flex items-center justify-center">
                <ProviderIcon size={20} />
              </div>
            </div>
            <div className="ml-3">
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">{project.name}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">{project.repository.fullName}</p>
            </div>
          </div>
          
          {project.lastBuild && (
            <BuildStatusBadge status={project.lastBuild.status} />
          )}
        </div>
        
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-gray-50 dark:bg-gray-900 p-3 rounded-lg">
            <p className="text-sm text-gray-500 dark:text-gray-400">Success Rate</p>
            <div className="flex items-center mt-1">
              <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full mr-2">
                <div 
                  className={`h-2 rounded-full ${
                    project.successRate >= 90 
                      ? 'bg-green-500' 
                      : project.successRate >= 70 
                        ? 'bg-yellow-500' 
                        : 'bg-red-500'
                  }`} 
                  style={{ width: `${project.successRate}%` }}
                ></div>
              </div>
              <span className="text-sm font-medium">{project.successRate}%</span>
            </div>
          </div>
          
          <div className="bg-gray-50 dark:bg-gray-900 p-3 rounded-lg">
            <p className="text-sm text-gray-500 dark:text-gray-400">Total Builds</p>
            <p className="text-lg font-semibold mt-1">{project.totalBuilds}</p>
          </div>
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-500 dark:text-gray-400">
              {project.lastBuild 
                ? `Last build ${formatDistanceToNow(new Date(project.lastBuild.startedAt), { addSuffix: true })}` 
                : 'No builds yet'}
            </div>
            
            <div className="flex space-x-2">
              <Link
                to={`/dashboard/projects/${project.id}/settings`}
                className="inline-flex items-center p-1.5 border border-gray-300 dark:border-gray-600 rounded text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                <Settings size={16} />
              </Link>
              
              <Link
                to={`/dashboard/projects/${project.id}`}
                className="inline-flex items-center p-1.5 border border-gray-300 dark:border-gray-600 rounded text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                <Package size={16} />
              </Link>
              
              <button
                className="inline-flex items-center p-1.5 border border-primary-500 rounded text-white bg-primary-500 hover:bg-primary-600"
              >
                <Play size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
 