import  { motion } from 'framer-motion';
import { ArrowUp, ArrowDown } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: string | number;
  change?: {
    value: number;
    trend: 'up' | 'down' | 'neutral';
  };
  icon: React.ReactNode;
  color?: string;
}

export default function StatsCard({ title, value, change, icon, color = 'text-blue-500' }: StatsCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700"
    >
      <div className="flex items-center">
        <div className={`p-2 rounded-lg ${color.replace('text-', 'bg-').replace('-500', '-100')} dark:bg-opacity-10`}>
          <div className={color}>{icon}</div>
        </div>
        <div className="ml-auto">
          {change && (
            <div className={`flex items-center text-sm ${
              change.trend === 'up' 
                ? 'text-green-600 dark:text-green-400' 
                : change.trend === 'down' 
                  ? 'text-red-600 dark:text-red-400' 
                  : 'text-gray-600 dark:text-gray-400'
            }`}>
              {change.trend === 'up' ? (
                <ArrowUp size={16} className="mr-1" />
              ) : change.trend === 'down' ? (
                <ArrowDown size={16} className="mr-1" />
              ) : null}
              {change.value}%
            </div>
          )}
        </div>
      </div>
      
      <div className="mt-4">
        <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">
          {title}
        </h3>
        <p className="text-2xl font-semibold text-gray-900 dark:text-white mt-1">
          {value}
        </p>
      </div>
    </motion.div>
  );
}
 