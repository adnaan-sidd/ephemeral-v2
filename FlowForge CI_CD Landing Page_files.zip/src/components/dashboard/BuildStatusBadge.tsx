import  { motion } from 'framer-motion';
import { Check, X, Clock, Pause, RefreshCw } from 'lucide-react';

interface BuildStatusBadgeProps {
  status: 'queued' | 'running' | 'success' | 'failed' | 'cancelled';
  size?: 'sm' | 'md' | 'lg';
  animated?: boolean;
}

export default function BuildStatusBadge({ status, size = 'md', animated = true }: BuildStatusBadgeProps) {
  const statusConfig = {
    queued: {
      color: 'bg-gray-100 dark:bg-gray-700',
      textColor: 'text-gray-700 dark:text-gray-300',
      icon: <Clock size={size === 'sm' ? 12 : size === 'md' ? 16 : 20} />,
      label: 'Queued'
    },
    running: {
      color: 'bg-blue-100 dark:bg-blue-900/30',
      textColor: 'text-blue-700 dark:text-blue-300',
      icon: <RefreshCw size={size === 'sm' ? 12 : size === 'md' ? 16 : 20} />,
      label: 'Running'
    },
    success: {
      color: 'bg-green-100 dark:bg-green-900/30',
      textColor: 'text-green-700 dark:text-green-300',
      icon: <Check size={size === 'sm' ? 12 : size === 'md' ? 16 : 20} />,
      label: 'Success'
    },
    failed: {
      color: 'bg-red-100 dark:bg-red-900/30',
      textColor: 'text-red-700 dark:text-red-300',
      icon: <X size={size === 'sm' ? 12 : size === 'md' ? 16 : 20} />,
      label: 'Failed'
    },
    cancelled: {
      color: 'bg-yellow-100 dark:bg-yellow-900/30',
      textColor: 'text-yellow-700 dark:text-yellow-300',
      icon: <Pause size={size === 'sm' ? 12 : size === 'md' ? 16 : 20} />,
      label: 'Cancelled'
    }
  };
  
  const config = statusConfig[status];
  
  const iconClasses = `${config.textColor} ${status === 'running' && animated ? 'animate-spin' : ''}`;
  
  const sizeClasses = {
    sm: 'px-1.5 py-0.5 text-xs',
    md: 'px-2 py-1 text-sm',
    lg: 'px-3 py-1.5 text-base'
  };
  
  return (
    <div className={`inline-flex items-center ${config.color} ${config.textColor} rounded-full ${sizeClasses[size]}`}>
      <span className={iconClasses}>
        {config.icon}
      </span>
      {size !== 'sm' && (
        <span className="ml-1 font-medium">
          {config.label}
        </span>
      )}
    </div>
  );
}
 