import  { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  BarChart, 
  Settings, 
  Package, 
  Zap, 
  Code, 
  User,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Bell,
  CreditCard
} from 'lucide-react';
import Logo from '../Logo';
import { useAuth } from '../../context/AuthContext';

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  const { user, logout } = useAuth();
  
  const menuItems = [
    { 
      name: 'Dashboard', 
      icon: <BarChart size={20} />, 
      path: '/dashboard',
      active: location.pathname === '/dashboard'
    },
    { 
      name: 'Projects', 
      icon: <Package size={20} />, 
      path: '/dashboard/projects',
      active: location.pathname.startsWith('/dashboard/projects')
    },
    { 
      name: 'Builds', 
      icon: <Zap size={20} />, 
      path: '/dashboard/builds',
      active: location.pathname.startsWith('/dashboard/builds')
    },
    { 
      name: 'Pipelines', 
      icon: <Code size={20} />, 
      path: '/dashboard/pipelines',
      active: location.pathname.startsWith('/dashboard/pipelines')
    },
    { 
      name: 'Analytics', 
      icon: <BarChart size={20} />, 
      path: '/dashboard/analytics',
      active: location.pathname.startsWith('/dashboard/analytics')
    },
    { 
      name: 'Billing', 
      icon: <CreditCard size={20} />, 
      path: '/dashboard/billing',
      active: location.pathname.startsWith('/dashboard/billing')
    },
    { 
      name: 'Notifications', 
      icon: <Bell size={20} />, 
      path: '/dashboard/notifications',
      active: location.pathname.startsWith('/dashboard/notifications')
    },
    { 
      name: 'Settings', 
      icon: <Settings size={20} />, 
      path: '/dashboard/settings',
      active: location.pathname.startsWith('/dashboard/settings')
    },
  ];
  
  return (
    <motion.div
      initial={{ x: -20, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.3 }}
      className={`fixed top-0 left-0 z-40 h-screen bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transition-all duration-300 ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      <div className="flex flex-col h-full">
        {/* Logo and collapse button */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
          <Link to="/dashboard" className="flex-shrink-0">
            {collapsed ? (
              <Logo size="sm" animated={false} className="-ml-1" />
            ) : (
              <Logo size="md" animated={false} />
            )}
          </Link>
          
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="p-1.5 rounded-lg text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            {collapsed ? (
              <ChevronRight size={18} />
            ) : (
              <ChevronLeft size={18} />
            )}
          </button>
        </div>
        
        {/* Navigation menu */}
        <nav className="flex-1 overflow-y-auto py-4 px-3">
          <ul className="space-y-2">
            {menuItems.map((item) => (
              <li key={item.name}>
                <Link
                  to={item.path}
                  className={`flex items-center p-2 rounded-lg ${
                    item.active
                      ? 'bg-gray-100 dark:bg-gray-700 text-blue-600 dark:text-blue-400'
                      : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                  } transition-colors`}
                >
                  <span className="flex-shrink-0">{item.icon}</span>
                  {!collapsed && (
                    <span className="ml-3">{item.name}</span>
                  )}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        
        {/* User profile */}
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <div className={`flex ${collapsed ? 'flex-col items-center' : 'items-center'}`}>
            <img
              src={user?.avatar || 'https://randomuser.me/api/portraits/men/32.jpg'}
              alt={user?.name || 'User'}
              className={`rounded-full border-2 border-gray-200 dark:border-gray-700 ${
                collapsed ? 'w-10 h-10' : 'w-10 h-10'
              }`}
            />
            
            {!collapsed && (
              <div className="ml-3 flex-1 overflow-hidden">
                <div className="font-medium text-gray-900 dark:text-white truncate">
                  {user?.name || 'User'}
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-400 truncate">
                  {user?.email || 'user@example.com'}
                </div>
              </div>
            )}
            
            {!collapsed && (
              <button
                onClick={logout}
                className="ml-2 p-1.5 rounded-lg text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              >
                <LogOut size={18} />
              </button>
            )}
          </div>
          
          {collapsed && (
            <button
              onClick={logout}
              className="mt-4 p-1.5 rounded-lg text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors w-full flex justify-center"
            >
              <LogOut size={18} />
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
}
 