import  { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Filter, X } from 'lucide-react';
import { Build } from '../../types';
import BuildStatusBadge from './BuildStatusBadge';

interface BuildsTableProps {
  builds: Build[];
}

export default function BuildsTable({ builds }: BuildsTableProps) {
  const [statusFilter, setStatusFilter] = useState<string[]>([]);
  const [projectFilter, setProjectFilter] = useState('');
  
  // Apply filters to builds
  const filteredBuilds = builds.filter(build => {
    // Apply status filter
    if (statusFilter.length > 0 && !statusFilter.includes(build.status)) {
      return false;
    }
    
    // Apply project filter
    if (projectFilter && build.projectName.toLowerCase() !== projectFilter.toLowerCase()) {
      return false;
    }
    
    return true;
  });
  
  // Format duration nicely
  const formatDuration = (ms: number): string => {
    if (ms < 1000) return `${ms}ms`;
    
    const seconds = Math.floor(ms / 1000);
    if (seconds < 60) return `${seconds}s`;
    
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds}s`;
  };
  
  // Format date for display
  const formatDate = (date: Date): string => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      hour12: true
    }).format(date);
  };
  
  return (
    <div>
      {/* Filters */}
      <div className="px-6 py-3 bg-gray-50 dark:bg-gray-800/50 border-b border-gray-200 dark:border-gray-700 flex flex-wrap items-center gap-2">
        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mr-2">
          <Filter size={14} className="mr-1" />
          Filters:
        </div>
        
        <div className="flex flex-wrap gap-2">
          {/* Status filters */}
          {['queued', 'running', 'success', 'failed', 'cancelled'].map((status) => (
            <button
              key={status}
              onClick={() => {
                if (statusFilter.includes(status)) {
                  setStatusFilter(statusFilter.filter(s => s !== status));
                } else {
                  setStatusFilter([...statusFilter, status]);
                }
              }}
              className={`inline-flex items-center px-2 py-1 rounded-md text-xs font-medium ${
                statusFilter.includes(status)
                  ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
              }`}
            >
              <BuildStatusBadge status={status as any} size="sm" />
              <span className="ml-1 capitalize">{status}</span>
            </button>
          ))}
          
          {/* Clear all filters */}
          {(statusFilter.length > 0 || projectFilter) && (
            <button
              onClick={() => {
                setStatusFilter([]);
                setProjectFilter('');
              }}
              className="px-3 py-1.5 text-sm text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400"
            >
              <X size={14} className="inline mr-1" />
              Clear filters
            </button>
          )}
        </div>
      </div>
      
      {/* Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-800/50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Status
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Project / Branch
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Commit
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Duration
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Started
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Author
              </th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            {filteredBuilds.length > 0 ? (
              filteredBuilds.map((build, index) => (
                <motion.tr 
                  key={build.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  whileHover={{ backgroundColor: 'rgba(0, 0, 0, 0.02)' }}
                  className="hover:bg-gray-50 dark:hover:bg-gray-750 cursor-pointer"
                  onClick={() => window.location.href = `/dashboard/builds/${build.id}`}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <BuildStatusBadge status={build.status} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {build.projectName}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      {build.branch}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900 dark:text-white truncate max-w-xs">
                      {build.commitMessage}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      {build.commitSha.substring(0, 7)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                    {build.status === 'queued' ? 'Queued' : formatDuration(build.duration)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                    {formatDate(build.startedAt)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-300">
                    {build.author}
                  </td>
                </motion.tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="px-6 py-10 text-center text-gray-500 dark:text-gray-400">
                  No builds match your filter criteria.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
 