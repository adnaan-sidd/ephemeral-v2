import  { motion } from 'framer-motion';
import { Activity, Clock, Settings, HelpCircle } from 'lucide-react';
import { generateUsageData } from '../utils/data';
import DashboardCharts from '../components/dashboard/DashboardCharts';

export default function AnalyticsPage() {
  // In a real app, this would come from API calls via React Query
  const usageData = generateUsageData();
  
  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Analytics</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Get insights into your build performance and resource usage.
          </p>
        </div>
        
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold">Build Metrics</h2>
            
            <div className="flex items-center space-x-3">
              <button className="inline-flex items-center px-3 py-1.5 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700">
                <Settings size={16} className="mr-1.5" />
                Customize
              </button>
              
              <button className="inline-flex items-center px-3 py-1.5 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700">
                <Activity size={16} className="mr-1.5" />
                Export
              </button>
            </div>
          </div>
          
          <DashboardCharts 
            buildActivityData={usageData.buildActivity}
            buildDurationData={usageData.buildDuration}
            resourceUsageData={usageData.resourceUsage}
          />
        </div>
        
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-6">Performance Insights</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Build Speed</h3>
                <HelpCircle size={16} className="text-gray-400" />
              </div>
              
              <div className="flex items-center">
                <Clock size={40} className="text-primary-500 mr-4" />
                <div>
                  <div className="text-3xl font-bold">4.2 <span className="text-lg font-medium text-gray-500">min</span></div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Average build time</div>
                </div>
              </div>
              
              <div className="mt-4">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Recent trend</span>
                  <span className="text-sm text-green-600 dark:text-green-400">-12%</span>
                </div>
                <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full">
                  <div className="h-2 rounded-full bg-green-500" style={{ width: '65%' }}></div>
                </div>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Success Rate</h3>
                <HelpCircle size={16} className="text-gray-400" />
              </div>
              
              <div className="flex items-center">
                <div className="relative mr-4">
                  <svg className="w-10 h-10" viewBox="0 0 36 36">
                    <circle cx="18" cy="18" r="16" fill="none" stroke="#E2E8F0" strokeWidth="2"></circle>
                    <circle cx="18" cy="18" r="16" fill="none" stroke="#10B981" strokeWidth="2" strokeDasharray="100" strokeDashoffset="8" strokeLinecap="round" transform="rotate(-90 18 18)"></circle>
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center text-sm font-medium">92%</div>
                </div>
                <div>
                  <div className="text-3xl font-bold">92<span className="text-lg font-medium text-gray-500">%</span></div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Build success rate</div>
                </div>
              </div>
              
              <div className="mt-4">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Recent trend</span>
                  <span className="text-sm text-green-600 dark:text-green-400">+3%</span>
                </div>
                <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full">
                  <div className="h-2 rounded-full bg-green-500" style={{ width: '92%' }}></div>
                </div>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Queue Time</h3>
                <HelpCircle size={16} className="text-gray-400" />
              </div>
              
              <div className="flex items-center">
                <Clock size={40} className="text-amber-500 mr-4" />
                <div>
                  <div className="text-3xl font-bold">22 <span className="text-lg font-medium text-gray-500">sec</span></div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Average wait time</div>
                </div>
              </div>
              
              <div className="mt-4">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-600 dark:text-gray-400">Recent trend</span>
                  <span className="text-sm text-amber-600 dark:text-amber-400">+5%</span>
                </div>
                <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full">
                  <div className="h-2 rounded-full bg-amber-500" style={{ width: '40%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-6">Usage Breakdown</h2>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
            <div className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-semibold">Build Minutes by Project</h3>
                  <p className="text-gray-500 dark:text-gray-400 text-sm">
                    Total: 7,532 minutes used this month
                  </p>
                </div>
                
                <div className="mt-4 lg:mt-0">
                  <img 
                    src="https://images.unsplash.com/photo-1587400563263-e77a5590bfe7?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxtb2Rlcm4lMjB1aSUyMGRhc2hib2FyZCUyMGRhdGElMjB2aXN1YWxpemF0aW9uJTIwY2hhcnRzfGVufDB8fHx8MTc0OTcwNTQ4NHww&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800" 
                    alt="Analytics Visualization"
                    className="rounded-lg h-48 object-cover"
                  />
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-primary-500 rounded-full mr-2"></div>
                      <span className="text-sm font-medium">web-frontend</span>
                    </div>
                    <span className="text-sm font-medium">2,845 min (38%)</span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full">
                    <div className="h-2 rounded-full bg-primary-500" style={{ width: '38%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                      <span className="text-sm font-medium">api-backend</span>
                    </div>
                    <span className="text-sm font-medium">1,970 min (26%)</span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full">
                    <div className="h-2 rounded-full bg-blue-500" style={{ width: '26%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-purple-500 rounded-full mr-2"></div>
                      <span className="text-sm font-medium">mobile-app</span>
                    </div>
                    <span className="text-sm font-medium">1,205 min (16%)</span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full">
                    <div className="h-2 rounded-full bg-purple-500" style={{ width: '16%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                      <span className="text-sm font-medium">infrastructure</span>
                    </div>
                    <span className="text-sm font-medium">902 min (12%)</span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full">
                    <div className="h-2 rounded-full bg-green-500" style={{ width: '12%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
                      <span className="text-sm font-medium">Other projects</span>
                    </div>
                    <span className="text-sm font-medium">610 min (8%)</span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full">
                    <div className="h-2 rounded-full bg-yellow-500" style={{ width: '8%' }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
 