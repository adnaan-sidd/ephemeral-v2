import  { motion } from 'framer-motion';
import { Plus } from 'lucide-react';
import DashboardLayout from '../components/dashboard/DashboardLayout';
import StatsCard from '../components/dashboard/StatsCard';
import BuildsTable from '../components/dashboard/BuildsTable';
import DashboardCharts from '../components/dashboard/DashboardCharts';
import { generateProjects, generateBuilds, generateDashboardStats, generateUsageData } from '../utils/data';

export default function DashboardPage() {
  // In a real app, this would come from API calls via React Query
  const stats = generateDashboardStats();
  const projects = generateProjects();
  const builds = generateBuilds(projects);
  const usageData = generateUsageData();
  
  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
              <p className="text-gray-600 dark:text-gray-400">Welcome back! Here's an overview of your CI/CD pipelines.</p>
            </div>
            
            <div className="mt-4 md:mt-0">
              <button className="inline-flex items-center px-3 py-1.5 border border-primary-500 rounded-md shadow-sm text-primary-600 dark:text-primary-400 bg-white dark:bg-gray-800 hover:bg-primary-50 dark:hover:bg-gray-700 transition-colors">
                <Plus size={16} className="mr-1.5" />
                New Build
              </button>
            </div>
          </div>
          
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {stats.map((stat, index) => (
              <StatsCard
                key={index}
                title={stat.title}
                value={stat.value}
                change={stat.change}
                icon={stat.icon}
                color={stat.color}
              />
            ))}
          </div>
          
          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <DashboardCharts
              title="Build Activity"
              description="Total builds per day"
              data={usageData.buildActivity}
              dataKeys={[
                { key: 'success', name: 'Success', color: '#10B981' },
                { key: 'failed', name: 'Failed', color: '#EF4444' }
              ]}
              timeRange="30d"
              onTimeRangeChange={(range) => console.log(range)}
            />
            
            <DashboardCharts
              title="Average Build Duration"
              description="Time in minutes"
              data={usageData.buildDuration}
              dataKeys={[
                { key: 'duration', name: 'Duration', color: '#6366F1' }
              ]}
              timeRange="30d"
              onTimeRangeChange={(range) => console.log(range)}
            />
          </div>
          
          {/* Recent Builds */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden mb-8">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
              <div>
                <h2 className="text-lg font-medium text-gray-900 dark:text-white">Recent Builds</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400">Your most recent build activities</p>
              </div>
              <a href="/dashboard/builds" className="text-sm text-blue-600 dark:text-blue-400 hover:underline">
                View all
              </a>
            </div>
            
            <BuildsTable builds={builds.slice(0, 5)} />
          </div>
        </motion.div>
      </div>
    </DashboardLayout>
  );
}
 