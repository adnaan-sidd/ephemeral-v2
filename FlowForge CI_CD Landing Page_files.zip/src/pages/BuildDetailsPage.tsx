import  { useParams } from 'react-router-dom';
import { generateProjects, generateBuilds } from '../utils/data';
import BuildDetails from '../components/dashboard/BuildDetailsPage';

export default function BuildDetailsPage() {
  const { id } = useParams<{ id: string }>();
  
  // In a real app, this would come from API calls via React Query
  const projects = generateProjects();
  const builds = generateBuilds(projects);
  
  // Find the build with the matching ID
  const build = builds.find(build => build.id === id);
  
  if (!build) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold mb-2">Build Not Found</h2>
          <p className="text-gray-600 dark:text-gray-400">
            The build you're looking for doesn't exist or you don't have permission to view it.
          </p>
        </div>
      </div>
    );
  }
  
  return <BuildDetails build={build} />;
}
 