import  { motion } from 'framer-motion';
import { generateProjects, generateBuilds } from '../utils/data';
import BuildsTable from '../components/dashboard/BuildsTable';

export default function BuildsPage() {
  // In a real app, this would come from API calls via React Query
  const projects = generateProjects();
  const builds = generateBuilds(projects);
  
  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Builds</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            View and manage all builds across your projects.
          </p>
        </div>
        
        <BuildsTable builds={builds} />
      </motion.div>
    </div>
  );
}
 